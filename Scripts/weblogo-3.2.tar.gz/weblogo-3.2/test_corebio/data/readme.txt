
# Name                  Description

AST1.fa			fasta fle with one sequence
AST2.fa                 Another fasta file
Rv3829c.fasta           a single fasta sequence (from BLAST2 parser )
Rv3829c.blast	        example BLAST version 2.10.0 output 
Rv3829c.psiblast        example PSI-BLAST version 2.10.0 output
TAT_mase_nuc.txt        An IG (intelligenetics) sequence file
blosum35.blast
blosum35.blast.new
clustal.aln            
clustal181.aln
clustal_glualign.aln
clustalw182.aln
clustalw.pir		PIR file from clustalw
cox2.gb
cox2.gcg
cox2.msf
cox2.nbrf
cox2.phylip             phylip format
cox2b.phylip		phylip format
crab.nbrf
dist.20comp
dna.phy			phylip format
dna.pir
globin.fa		A multiple sequence alignment fasta file
intelligenetics.txt     An IG (intelligenetics) sequence file
pam250.mat
protein.pir



 